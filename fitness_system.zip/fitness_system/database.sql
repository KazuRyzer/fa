-- =============================================
-- FITNESS CENTER MANAGEMENT SYSTEM - DATABASE
-- =============================================

-- Buat database baru
CREATE DATABASE IF NOT EXISTS fitness_db;
USE fitness_db;

-- =============================================
-- TABLE 1: trainers (Maklumat Trainer)
-- =============================================
CREATE TABLE trainers (
    trainer_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- =============================================
-- TABLE 2: clients (Maklumat Klien)
-- =============================================
CREATE TABLE clients (
    client_id INT AUTO_INCREMENT PRIMARY KEY,
    trainer_id INT NOT NULL,
    client_name VARCHAR(100) NOT NULL,
    age INT NOT NULL,
    gender ENUM('Male', 'Female') NOT NULL,
    phone VARCHAR(20) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (trainer_id) REFERENCES trainers(trainer_id) ON DELETE CASCADE
);

-- =============================================
-- TABLE 3: workouts (Rekod Workout Klien)
-- =============================================
CREATE TABLE workouts (
    workout_id INT AUTO_INCREMENT PRIMARY KEY,
    client_id INT NOT NULL,
    duration INT NOT NULL,
    calories_per_minute FLOAT NOT NULL,
    total_calories FLOAT NOT NULL,
    calorie_level VARCHAR(10) NOT NULL,
    workout_date DATE NOT NULL,
    FOREIGN KEY (client_id) REFERENCES clients(client_id) ON DELETE CASCADE
);
