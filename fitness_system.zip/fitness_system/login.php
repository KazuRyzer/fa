<?php
session_start();
include 'config.php';

// Kalau dah login, terus pergi dashboard
if (isset($_SESSION['trainer_id'])) {
    header("Location: dashboard.php");
    exit();
}

$error = "";

// Proses form bila butang Login ditekan
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // ========================
    // VALIDATION
    // ========================

    if (empty($username) || empty($password)) {
        $error = "⚠️ Username dan Password mesti diisi!";
    } else {
        // Cari trainer dalam database berdasarkan username
        $sql = "SELECT * FROM trainers WHERE username = '$username'";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) == 1) {
            $trainer = mysqli_fetch_assoc($result);

            // Semak password betul atau tidak
            if (password_verify($password, $trainer['password'])) {
                // Login berjaya - simpan maklumat dalam session
                $_SESSION['trainer_id']   = $trainer['trainer_id'];
                $_SESSION['trainer_name'] = $trainer['full_name'];

                // Redirect ke dashboard
                header("Location: dashboard.php");
                exit();
            } else {
                $error = "❌ Password salah. Sila cuba lagi.";
            }
        } else {
            $error = "❌ Username tidak dijumpai. Sila daftar dahulu.";
        }
    }
}
?>

<?php include 'header.php'; ?>
<?php include 'navbar.php'; ?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card p-4">
                <h2 class="text-center">🔐 Login Trainer</h2>

                <!-- Paparkan mesej error -->
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>

                <!-- Paparkan mesej dari halaman lain (contoh: selepas logout) -->
                <?php if (isset($_SESSION['message'])): ?>
                    <div class="alert alert-info"><?php echo $_SESSION['message']; unset($_SESSION['message']); ?></div>
                <?php endif; ?>

                <!-- Form Login -->
                <form method="POST" action="login.php">

                    <div class="mb-3">
                        <label>Username</label>
                        <input type="text" name="username" class="form-control"
                               placeholder="Masukkan username">
                    </div>

                    <div class="mb-3">
                        <label>Password</label>
                        <input type="password" name="password" class="form-control"
                               placeholder="Masukkan password">
                    </div>

                    <button type="submit" class="btn btn-success w-100">Login</button>
                </form>

                <p class="text-center mt-3">
                    Belum ada akaun? <a href="register.php">Daftar di sini</a>
                </p>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
