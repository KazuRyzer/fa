<?php
session_start();
include 'config.php';

$error = "";
$success = "";

// Proses form bila butang Submit ditekan
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Ambil data dari form
    $full_name = trim($_POST['full_name']);
    $username  = trim($_POST['username']);
    $password  = trim($_POST['password']);
    $email     = trim($_POST['email']);

    // ========================
    // VALIDATION
    // ========================

    // Semak semua field tidak kosong
    if (empty($full_name) || empty($username) || empty($password) || empty($email)) {
        $error = "⚠️ Semua field mesti diisi!";

    // Semak username sekurang-kurangnya 6 aksara
    } elseif (strlen($username) < 6) {
        $error = "⚠️ Username mesti sekurang-kurangnya 6 aksara!";

    // Semak password sekurang-kurangnya 6 aksara
    } elseif (strlen($password) < 6) {
        $error = "⚠️ Password mesti sekurang-kurangnya 6 aksara!";

    } else {
        // Semak sama ada username sudah wujud dalam database
        $check = mysqli_query($conn, "SELECT * FROM trainers WHERE username = '$username'");

        if (mysqli_num_rows($check) > 0) {
            $error = "⚠️ Username sudah digunakan. Sila pilih username lain.";
        } else {
            // Hash password untuk keselamatan
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Simpan data ke dalam database
            $sql = "INSERT INTO trainers (full_name, username, password, email)
                    VALUES ('$full_name', '$username', '$hashed_password', '$email')";

            if (mysqli_query($conn, $sql)) {
                $success = "✅ Pendaftaran berjaya! Anda akan dibawa ke halaman Login...";
                // Redirect ke login selepas 2 saat
                header("Refresh: 2; URL=login.php");
            } else {
                $error = "❌ Ralat semasa mendaftar. Sila cuba lagi.";
            }
        }
    }
}
?>

<?php include 'header.php'; ?>
<?php include 'navbar.php'; ?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card p-4">
                <h2 class="text-center">📝 Daftar Akaun Trainer</h2>

                <!-- Paparkan mesej error -->
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>

                <!-- Paparkan mesej berjaya -->
                <?php if (!empty($success)): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>

                <!-- Form Pendaftaran -->
                <form method="POST" action="register.php">

                    <div class="mb-3">
                        <label>Nama Penuh</label>
                        <input type="text" name="full_name" class="form-control"
                               placeholder="Masukkan nama penuh"
                               value="<?php echo htmlspecialchars($full_name ?? ''); ?>">
                    </div>

                    <div class="mb-3">
                        <label>Username <small class="text-muted">(min 6 aksara)</small></label>
                        <input type="text" name="username" class="form-control"
                               placeholder="Masukkan username"
                               value="<?php echo htmlspecialchars($username ?? ''); ?>">
                    </div>

                    <div class="mb-3">
                        <label>Password <small class="text-muted">(min 6 aksara)</small></label>
                        <input type="password" name="password" class="form-control"
                               placeholder="Masukkan password">
                    </div>

                    <div class="mb-3">
                        <label>Email</label>
                        <input type="email" name="email" class="form-control"
                               placeholder="Masukkan email"
                               value="<?php echo htmlspecialchars($email ?? ''); ?>">
                    </div>

                    <button type="submit" class="btn btn-primary w-100">Daftar Sekarang</button>
                </form>

                <p class="text-center mt-3">
                    Sudah ada akaun? <a href="login.php">Login di sini</a>
                </p>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
