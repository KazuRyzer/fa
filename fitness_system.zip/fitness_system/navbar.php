<?php
// Pastikan session sudah dimulakan
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <!-- Nama Sistem -->
        <a class="navbar-brand" href="dashboard.php">💪 Fitness Center</a>

        <!-- Butang untuk mobile -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMenu">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Menu items -->
        <div class="collapse navbar-collapse" id="navbarMenu">
            <ul class="navbar-nav ms-auto">

                <?php if (isset($_SESSION['trainer_id'])): ?>
                    <!-- Menu kalau dah login -->
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">🏠 Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <span class="nav-link text-warning">
                            👤 <?php echo htmlspecialchars($_SESSION['trainer_name']); ?>
                        </span>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-danger" href="logout.php">🚪 Logout</a>
                    </li>
                <?php else: ?>
                    <!-- Menu kalau belum login -->
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="register.php">Register</a>
                    </li>
                <?php endif; ?>

            </ul>
        </div>
    </div>
</nav>
