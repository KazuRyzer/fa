    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <footer class="text-center mt-5 py-3 bg-dark text-white">
        <p class="mb-0">&copy; 2025 Fitness Center Management System. All Rights Reserved.</p>
    </footer>

</body>
</html>
