# 🏋️ Fitness Center Management System
## Cara Setup (Guna XAMPP)

### Langkah 1 - Setup XAMPP
1. Buka XAMPP Control Panel
2. Start **Apache** dan **MySQL**

### Langkah 2 - Setup Database
1. Buka browser → pergi ke `http://localhost/phpmyadmin`
2. Klik **"New"** → taip nama database: `fitness_db` → klik **Create**
3. Klik tab **SQL** → copy semua isi dari `database.sql` → klik **Go**

### Langkah 3 - Letak Fail PHP
1. Copy semua fail `.php` ke dalam folder:
   ```
   C:\xampp\htdocs\fitness_system\
   ```

### Langkah 4 - Buka Sistem
1. Buka browser → pergi ke:
   ```
   http://localhost/fitness_system/register.php
   ```
2. Daftar akaun trainer → Login → Mula guna sistem!

---

## 📁 Senarai Fail

| Fail | Fungsi |
|------|--------|
| `database.sql` | SQL untuk buat database & table |
| `config.php` | Sambungan ke database |
| `header.php` | Header HTML (reusable) |
| `footer.php` | Footer HTML (reusable) |
| `navbar.php` | Navigation bar (reusable) |
| `register.php` | Halaman daftar trainer baru |
| `login.php` | Halaman login |
| `dashboard.php` | Halaman utama - senarai klien |
| `add_client.php` | Tambah klien baru |
| `update_client.php` | Kemaskini maklumat klien |
| `delete_client.php` | Padam klien |
| `workout.php` | Rekod workout & kira kalori |
| `logout.php` | Log keluar sistem |

---

## 🔢 Formula Kalori
```
Total Kalori = Tempoh (minit) × Kalori per Minit

Tahap:
- Low    = < 100 kcal
- Medium = 100 - 300 kcal  
- High   = > 300 kcal
```
