<?php
session_start();
include 'config.php';

// ========================
// SEMAK SESSION - Hanya trainer yang login boleh masuk
// ========================
if (!isset($_SESSION['trainer_id'])) {
    header("Location: login.php");
    exit();
}

$trainer_id = $_SESSION['trainer_id'];

// Ambil semua klien yang dimiliki trainer ini
$sql = "SELECT * FROM clients WHERE trainer_id = '$trainer_id' ORDER BY created_at DESC";
$result = mysqli_query($conn, $sql);
?>

<?php include 'header.php'; ?>
<?php include 'navbar.php'; ?>

<div class="container mt-4">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>🏋️ Dashboard - Senarai Klien</h2>
        <!-- Butang untuk tambah klien baru -->
        <a href="add_client.php" class="btn btn-primary">➕ Tambah Klien</a>
    </div>

    <!-- Paparkan mesej jika ada -->
    <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-success"><?php echo $_SESSION['message']; unset($_SESSION['message']); ?></div>
    <?php endif; ?>

    <!-- Jadual senarai klien -->
    <div class="card">
        <div class="card-body">
            <?php if (mysqli_num_rows($result) == 0): ?>
                <!-- Tiada klien lagi -->
                <p class="text-center text-muted">Tiada klien didaftarkan lagi. Klik "Tambah Klien" untuk mula!</p>
            <?php else: ?>
                <table class="table table-bordered table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th>#</th>
                            <th>Nama Klien</th>
                            <th>Umur</th>
                            <th>Jantina</th>
                            <th>No. Telefon</th>
                            <th>Tindakan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $bil = 1;
                        while ($client = mysqli_fetch_assoc($result)):
                        ?>
                        <tr>
                            <td><?php echo $bil++; ?></td>
                            <td><?php echo htmlspecialchars($client['client_name']); ?></td>
                            <td><?php echo $client['age']; ?></td>
                            <td><?php echo $client['gender']; ?></td>
                            <td><?php echo htmlspecialchars($client['phone']); ?></td>
                            <td>
                                <!-- Butang Workout -->
                                <a href="workout.php?id=<?php echo $client['client_id']; ?>"
                                   class="btn btn-sm btn-success">💪 Workout</a>

                                <!-- Butang Kemaskini -->
                                <a href="update_client.php?id=<?php echo $client['client_id']; ?>"
                                   class="btn btn-sm btn-warning">✏️ Kemaskini</a>

                                <!-- Butang Padam -->
                                <a href="delete_client.php?id=<?php echo $client['client_id']; ?>"
                                   class="btn btn-sm btn-danger"
                                   onclick="return confirm('Adakah anda pasti mahu padam klien ini?')">
                                   🗑️ Padam
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
