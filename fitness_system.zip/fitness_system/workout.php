<?php
session_start();
include 'config.php';

// Semak session
if (!isset($_SESSION['trainer_id'])) {
    header("Location: login.php");
    exit();
}

$trainer_id = $_SESSION['trainer_id'];
$error = "";

// Ambil ID klien dari URL
$client_id = $_GET['id'];

// Ambil data klien
$sql = "SELECT * FROM clients WHERE client_id = '$client_id' AND trainer_id = '$trainer_id'";
$result = mysqli_query($conn, $sql);
$client = mysqli_fetch_assoc($result);

if (!$client) {
    header("Location: dashboard.php");
    exit();
}

// ========================
// FUNGSI KIRA KALORI
// ========================
function kiraTotalCalories($duration, $calories_per_minute) {
    // Formula: Kalori = Tempoh × Kalori per minit
    $total = $duration * $calories_per_minute;
    return $total;
}

// Fungsi tentukan tahap kalori
function tahapKalori($total_calories) {
    if ($total_calories < 100) {
        return "Low";
    } elseif ($total_calories <= 300) {
        return "Medium";
    } else {
        return "High";
    }
}

// Proses form workout
$total_calories = 0;
$calorie_level  = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $duration            = trim($_POST['duration']);
    $calories_per_minute = trim($_POST['calories_per_minute']);
    $workout_date        = $_POST['workout_date'];

    // ========================
    // VALIDATION
    // ========================

    if (empty($duration) || empty($calories_per_minute) || empty($workout_date)) {
        $error = "⚠️ Semua field mesti diisi!";

    } elseif (!is_numeric($duration) || !is_numeric($calories_per_minute)) {
        $error = "⚠️ Tempoh dan kalori mesti nilai nombor sahaja!";

    } else {
        // Kira kalori menggunakan fungsi
        $total_calories = kiraTotalCalories($duration, $calories_per_minute);
        $calorie_level  = tahapKalori($total_calories);

        // Simpan ke database
        $sql = "INSERT INTO workouts (client_id, duration, calories_per_minute, total_calories, calorie_level, workout_date)
                VALUES ('$client_id', '$duration', '$calories_per_minute', '$total_calories', '$calorie_level', '$workout_date')";

        if (mysqli_query($conn, $sql)) {
            $_SESSION['message'] = "✅ Rekod workout berjaya disimpan! Total Kalori: $total_calories kcal ($calorie_level)";
            header("Location: dashboard.php");
            exit();
        } else {
            $error = "❌ Ralat semasa menyimpan workout.";
        }
    }
}
?>

<?php include 'header.php'; ?>
<?php include 'navbar.php'; ?>

<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card p-4">
                <h2>💪 Rekod Workout</h2>
                <p class="text-muted">Klien: <strong><?php echo htmlspecialchars($client['client_name']); ?></strong></p>

                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>

                <form method="POST" action="workout.php?id=<?php echo $client_id; ?>">

                    <div class="mb-3">
                        <label>Tempoh Workout (minit)</label>
                        <input type="text" name="duration" class="form-control"
                               placeholder="Contoh: 30"
                               value="<?php echo htmlspecialchars($duration ?? ''); ?>">
                    </div>

                    <div class="mb-3">
                        <label>Kalori Terbakar Per Minit</label>
                        <input type="text" name="calories_per_minute" class="form-control"
                               placeholder="Contoh: 5.5"
                               value="<?php echo htmlspecialchars($calories_per_minute ?? ''); ?>">
                    </div>

                    <div class="mb-3">
                        <label>Tarikh Workout</label>
                        <input type="date" name="workout_date" class="form-control"
                               value="<?php echo $workout_date ?? date('Y-m-d'); ?>">
                    </div>

                    <!-- Panduan tahap kalori -->
                    <div class="alert alert-info">
                        <strong>📊 Tahap Kalori:</strong><br>
                        🟢 Low = Kurang dari 100 kcal<br>
                        🟡 Medium = 100 - 300 kcal<br>
                        🔴 High = Lebih dari 300 kcal
                    </div>

                    <button type="submit" class="btn btn-success w-100">Simpan Rekod Workout</button>
                    <a href="dashboard.php" class="btn btn-secondary w-100 mt-2">Batal</a>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
