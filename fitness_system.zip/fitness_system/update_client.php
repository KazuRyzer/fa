<?php
session_start();
include 'config.php';

// Semak session
if (!isset($_SESSION['trainer_id'])) {
    header("Location: login.php");
    exit();
}

$trainer_id = $_SESSION['trainer_id'];
$error = "";

// Ambil ID klien dari URL
$client_id = $_GET['id'];

// Ambil data klien dari database
$sql = "SELECT * FROM clients WHERE client_id = '$client_id' AND trainer_id = '$trainer_id'";
$result = mysqli_query($conn, $sql);
$client = mysqli_fetch_assoc($result);

// Kalau klien tidak jumpa atau bukan milik trainer ini
if (!$client) {
    header("Location: dashboard.php");
    exit();
}

// Proses form kemaskini
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $client_name = trim($_POST['client_name']);
    $age         = trim($_POST['age']);
    $gender      = $_POST['gender'];
    $phone       = trim($_POST['phone']);

    // Validation
    if (empty($client_name) || empty($age) || empty($gender) || empty($phone)) {
        $error = "⚠️ Semua field mesti diisi!";
    } else {
        // Update data klien
        $sql = "UPDATE clients SET
                    client_name = '$client_name',
                    age = '$age',
                    gender = '$gender',
                    phone = '$phone'
                WHERE client_id = '$client_id' AND trainer_id = '$trainer_id'";

        if (mysqli_query($conn, $sql)) {
            $_SESSION['message'] = "✅ Maklumat klien berjaya dikemaskini!";
            header("Location: dashboard.php");
            exit();
        } else {
            $error = "❌ Ralat semasa kemaskini.";
        }
    }
}
?>

<?php include 'header.php'; ?>
<?php include 'navbar.php'; ?>

<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card p-4">
                <h2>✏️ Kemaskini Klien</h2>

                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>

                <form method="POST" action="update_client.php?id=<?php echo $client_id; ?>">

                    <div class="mb-3">
                        <label>Nama Klien</label>
                        <input type="text" name="client_name" class="form-control"
                               value="<?php echo htmlspecialchars($client['client_name']); ?>">
                    </div>

                    <div class="mb-3">
                        <label>Umur</label>
                        <input type="number" name="age" class="form-control"
                               value="<?php echo $client['age']; ?>">
                    </div>

                    <div class="mb-3">
                        <label>Jantina</label>
                        <select name="gender" class="form-select">
                            <option value="Male"   <?php if ($client['gender'] == 'Male')   echo 'selected'; ?>>Lelaki</option>
                            <option value="Female" <?php if ($client['gender'] == 'Female') echo 'selected'; ?>>Perempuan</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label>No. Telefon</label>
                        <input type="text" name="phone" class="form-control"
                               value="<?php echo htmlspecialchars($client['phone']); ?>">
                    </div>

                    <button type="submit" class="btn btn-warning w-100">Kemaskini</button>
                    <a href="dashboard.php" class="btn btn-secondary w-100 mt-2">Batal</a>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
