<?php
session_start();
include 'config.php';

// Semak session
if (!isset($_SESSION['trainer_id'])) {
    header("Location: login.php");
    exit();
}

$trainer_id = $_SESSION['trainer_id'];
$client_id  = $_GET['id'];

// Padam klien - hanya klien milik trainer ini boleh dipadam
$sql = "DELETE FROM clients WHERE client_id = '$client_id' AND trainer_id = '$trainer_id'";

if (mysqli_query($conn, $sql)) {
    $_SESSION['message'] = "🗑️ Klien berjaya dipadam!";
} else {
    $_SESSION['message'] = "❌ Ralat semasa memadam klien.";
}

// Redirect balik ke dashboard
header("Location: dashboard.php");
exit();
?>
