<?php
session_start();
include 'config.php';

// Semak session
if (!isset($_SESSION['trainer_id'])) {
    header("Location: login.php");
    exit();
}

$trainer_id = $_SESSION['trainer_id'];
$error = "";

// Proses form tambah klien
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $client_name = trim($_POST['client_name']);
    $age         = trim($_POST['age']);
    $gender      = $_POST['gender'];
    $phone       = trim($_POST['phone']);

    // Validation - semua field mesti diisi
    if (empty($client_name) || empty($age) || empty($gender) || empty($phone)) {
        $error = "⚠️ Semua field mesti diisi!";
    } else {
        // Simpan klien baru ke database
        $sql = "INSERT INTO clients (trainer_id, client_name, age, gender, phone)
                VALUES ('$trainer_id', '$client_name', '$age', '$gender', '$phone')";

        if (mysqli_query($conn, $sql)) {
            $_SESSION['message'] = "✅ Klien berjaya ditambah!";
            header("Location: dashboard.php");
            exit();
        } else {
            $error = "❌ Ralat semasa menambah klien.";
        }
    }
}
?>

<?php include 'header.php'; ?>
<?php include 'navbar.php'; ?>

<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card p-4">
                <h2>➕ Tambah Klien Baru</h2>

                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>

                <form method="POST" action="add_client.php">

                    <div class="mb-3">
                        <label>Nama Klien</label>
                        <input type="text" name="client_name" class="form-control"
                               placeholder="Masukkan nama klien"
                               value="<?php echo htmlspecialchars($client_name ?? ''); ?>">
                    </div>

                    <div class="mb-3">
                        <label>Umur</label>
                        <input type="number" name="age" class="form-control"
                               placeholder="Masukkan umur"
                               value="<?php echo $age ?? ''; ?>">
                    </div>

                    <div class="mb-3">
                        <label>Jantina</label>
                        <select name="gender" class="form-select">
                            <option value="">-- Pilih Jantina --</option>
                            <option value="Male">Lelaki</option>
                            <option value="Female">Perempuan</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label>No. Telefon</label>
                        <input type="text" name="phone" class="form-control"
                               placeholder="Contoh: 012-3456789"
                               value="<?php echo htmlspecialchars($phone ?? ''); ?>">
                    </div>

                    <button type="submit" class="btn btn-primary w-100">Simpan Klien</button>
                    <a href="dashboard.php" class="btn btn-secondary w-100 mt-2">Batal</a>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
