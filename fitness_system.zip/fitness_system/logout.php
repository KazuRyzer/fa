<?php
session_start();

// Simpan mesej sebelum destroy session
$_SESSION['message'] = "✅ Anda telah log keluar. Jumpa lagi!";

// Hapuskan semua data session
session_unset();

// Musnahkan session
session_destroy();

// Mulakan session baru untuk simpan mesej
session_start();
$_SESSION['message'] = "✅ Anda telah log keluar. Jumpa lagi!";

// Redirect ke halaman login
header("Location: login.php");
exit();
?>
