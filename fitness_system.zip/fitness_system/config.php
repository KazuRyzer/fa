<?php
// =============================================
// config.php - Sambungan ke Database
// =============================================

$host = "localhost";       // Server database
$dbname = "fitness_db";   // Nama database
$username = "root";        // Username MySQL
$password = "";            // Password MySQL (kosong untuk XAMPP)

// Buat sambungan menggunakan mysqli
$conn = mysqli_connect($host, $username, $password, $dbname);

// Semak sama ada sambungan berjaya atau tidak
if (!$conn) {
    die("Sambungan GAGAL: " . mysqli_connect_error());
}
?>
