<?php
// Mulakan session (kena ada di setiap page yang guna session)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <!-- Logo / Nama Sistem -->
        <a class="navbar-brand fw-bold" href="dashboard.php">📋 Sistem Aduan</a>

        <!-- Butang untuk mobile -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Menu navigasi -->
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav ms-auto">

                <?php if (isset($_SESSION['user_id'])): ?>
                    <!-- Menu kalau dah log masuk -->
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">🏠 Dashboard</a>
                    </li>

                    <?php if ($_SESSION['role'] == 'user'): ?>
                    <!-- Menu khusus untuk user biasa -->
                    <li class="nav-item">
                        <a class="nav-link" href="add_complaint.php">➕ Hantar Aduan</a>
                    </li>
                    <?php endif; ?>

                    <!-- Nama pengguna & logout -->
                    <li class="nav-item">
                        <span class="nav-link text-warning">👤 <?= htmlspecialchars($_SESSION['username']) ?></span>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">🚪 Log Keluar</a>
                    </li>

                <?php else: ?>
                    <!-- Menu kalau belum log masuk -->
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">🔑 Log Masuk</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="register.php">📝 Daftar</a>
                    </li>
                <?php endif; ?>

            </ul>
        </div>
    </div>
</nav>
