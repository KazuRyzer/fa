# 📋 Sistem Aduan Pelanggan - Cara Pasang

## Langkah-langkah Pemasangan

### 1. Pasang XAMPP
- Muat turun XAMPP dari https://www.apachefriends.org
- Pasang dan mulakan Apache + MySQL

### 2. Import Database
- Buka browser, pergi ke: http://localhost/phpmyadmin
- Klik "New" → buat database bernama `aduan`
- Klik database `aduan` → tab "Import"
- Upload fail `aduan.sql` → klik "Go"

### 3. Salin Fail
- Salin semua fail PHP ke folder: `C:\xampp\htdocs\aduan_system\`

### 4. Buka Sistem
- Buka browser: http://localhost/aduan_system/login.php

---

## Akaun Lalai

| Peranan | Username | Password |
|---------|----------|----------|
| Admin   | admin    | admin123 |

---

## Senarai Fail

| Fail | Fungsi |
|------|--------|
| `aduan.sql` | Struktur database |
| `config.php` | Sambungan database |
| `header.php` | Header HTML |
| `footer.php` | Footer HTML |
| `navbar.php` | Bar navigasi |
| `register.php` | Pendaftaran pengguna |
| `login.php` | Log masuk |
| `dashboard.php` | Papan pemuka (senarai aduan) |
| `add_complaint.php` | Hantar aduan baru |
| `update_status.php` | Kemaskini status aduan (Admin) |
| `delete_complaint.php` | Padam aduan (Admin) |
| `logout.php` | Log keluar |
