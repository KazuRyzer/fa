<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Aduan Pelanggan</title>

    <!-- Bootstrap CSS - untuk rekabentuk cantik -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

    <style>
        body {
            background-color: #f0f2f5;
        }
        .main-content {
            margin-top: 20px;
            margin-bottom: 40px;
        }
    </style>
</head>
<body>
