<?php
session_start();

// Buang semua data session
session_unset();
session_destroy();

// Redirect ke login page
header("Location: login.php");
exit();
?>
