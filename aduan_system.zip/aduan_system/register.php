<?php
session_start();
require 'config.php';

// Kalau dah log masuk, pergi dashboard terus
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

$error = "";
$success = "";

// Proses bila form dihantar
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Ambil data dari form & buang ruang kosong
    $username = trim($_POST['username']);
    $email    = trim($_POST['email']);
    $password = trim($_POST['password']);
    $confirm  = trim($_POST['confirm_password']);

    // ========== VALIDASI ==========

    // 1. Semak semua field diisi
    if (empty($username) || empty($email) || empty($password) || empty($confirm)) {
        $error = "Semua maklumat mesti diisi!";
    }
    // 2. Username mesti sekurang-kurangnya 6 aksara
    elseif (strlen($username) < 6) {
        $error = "Username mesti sekurang-kurangnya 6 aksara!";
    }
    // 3. Password mesti sekurang-kurangnya 6 aksara
    elseif (strlen($password) < 6) {
        $error = "Password mesti sekurang-kurangnya 6 aksara!";
    }
    // 4. Semak password sama
    elseif ($password !== $confirm) {
        $error = "Password tidak sepadan!";
    }
    // 5. Semak format email
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Format email tidak sah!";
    }
    else {
        // Semak kalau username dah wujud
        $check = $conn->prepare("SELECT id FROM users WHERE username = ?");
        $check->bind_param("s", $username);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $error = "Username sudah digunakan. Sila pilih yang lain.";
        } else {
            // Hash password (selamat!)
            $hashed = password_hash($password, PASSWORD_DEFAULT);

            // Simpan ke database
            $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $username, $email, $hashed);

            if ($stmt->execute()) {
                $success = "Pendaftaran berjaya! Sila log masuk.";
            } else {
                $error = "Ralat berlaku. Sila cuba lagi.";
            }
        }
    }
}
?>

<?php require 'header.php'; ?>
<?php require 'navbar.php'; ?>

<div class="container main-content">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow">
                <div class="card-header bg-success text-white text-center">
                    <h4>📝 Pendaftaran Pengguna Baru</h4>
                </div>
                <div class="card-body">

                    <!-- Papar mesej error -->
                    <?php if (!empty($error)): ?>
                        <div class="alert alert-danger"><?= $error ?></div>
                    <?php endif; ?>

                    <!-- Papar mesej berjaya -->
                    <?php if (!empty($success)): ?>
                        <div class="alert alert-success">
                            <?= $success ?>
                            <a href="login.php">Klik sini untuk Log Masuk</a>
                        </div>
                    <?php endif; ?>

                    <form method="POST">
                        <div class="mb-3">
                            <label>Username <span class="text-danger">*</span></label>
                            <input type="text" name="username" class="form-control"
                                   placeholder="Minimum 6 aksara"
                                   value="<?= isset($_POST['username']) ? htmlspecialchars($_POST['username']) : '' ?>">
                        </div>
                        <div class="mb-3">
                            <label>Email <span class="text-danger">*</span></label>
                            <input type="email" name="email" class="form-control"
                                   placeholder="contoh@email.com"
                                   value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>">
                        </div>
                        <div class="mb-3">
                            <label>Password <span class="text-danger">*</span></label>
                            <input type="password" name="password" class="form-control"
                                   placeholder="Minimum 6 aksara">
                        </div>
                        <div class="mb-3">
                            <label>Sahkan Password <span class="text-danger">*</span></label>
                            <input type="password" name="confirm_password" class="form-control"
                                   placeholder="Taip semula password">
                        </div>
                        <button type="submit" class="btn btn-success w-100">Daftar Sekarang</button>
                    </form>

                    <hr>
                    <p class="text-center">Sudah ada akaun? <a href="login.php">Log Masuk di sini</a></p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require 'footer.php'; ?>
