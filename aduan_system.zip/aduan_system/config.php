<?php
// =============================================
// config.php - Sambungan Database
// =============================================

$host     = "localhost";    // Nama server
$dbname   = "aduan";        // Nama database
$username = "root";         // Username MySQL
$password = "";             // Password MySQL (kosong kalau XAMPP default)

// Cuba sambung ke database
$conn = new mysqli($host, $username, $password, $dbname);

// Semak kalau sambungan berjaya
if ($conn->connect_error) {
    die("Sambungan gagal: " . $conn->connect_error);
}

// Tetapkan charset supaya Bahasa Melayu boleh papar
$conn->set_charset("utf8");
?>
