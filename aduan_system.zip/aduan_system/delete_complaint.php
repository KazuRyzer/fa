<?php
session_start();
require 'config.php';

// ===== KAWALAN AKSES =====
// Hanya admin boleh padam aduan
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Ambil ID dari URL
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Semak ID sah
if ($id <= 0) {
    header("Location: dashboard.php");
    exit();
}

// Padam aduan dari database
$stmt = $conn->prepare("DELETE FROM complaints WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    // Berjaya - redirect ke dashboard dengan mesej
    header("Location: dashboard.php?msg=deleted");
} else {
    // Gagal - redirect tanpa mesej
    header("Location: dashboard.php");
}
exit();
?>
