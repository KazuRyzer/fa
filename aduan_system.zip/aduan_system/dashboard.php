<?php
session_start();
require 'config.php';

// ===== KAWALAN AKSES =====
// Hanya yang log masuk boleh masuk dashboard
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$role    = $_SESSION['role'];

// ===== AMBIL DATA ADUAN =====
// Admin nampak semua aduan, user biasa nampak aduan sendiri sahaja
if ($role == 'admin') {
    // Admin - semua aduan + nama user
    $result = $conn->query("
        SELECT complaints.*, users.username
        FROM complaints
        JOIN users ON complaints.user_id = users.id
        ORDER BY complaints.created_at DESC
    ");
} else {
    // User biasa - aduan sendiri sahaja
    $stmt = $conn->prepare("SELECT * FROM complaints WHERE user_id = ? ORDER BY created_at DESC");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
}

// Papar mesej selepas delete
$msg = isset($_GET['msg']) ? $_GET['msg'] : "";
?>

<?php require 'header.php'; ?>
<?php require 'navbar.php'; ?>

<div class="container main-content">

    <!-- Heading -->
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>🏠 Dashboard
            <?php if ($role == 'admin'): ?>
                <span class="badge bg-danger">Admin</span>
            <?php endif; ?>
        </h3>
        <?php if ($role == 'user'): ?>
            <a href="add_complaint.php" class="btn btn-warning">➕ Hantar Aduan Baru</a>
        <?php endif; ?>
    </div>

    <!-- Papar mesej berjaya delete -->
    <?php if ($msg == 'deleted'): ?>
        <div class="alert alert-success">✅ Aduan telah berjaya dipadam!</div>
    <?php endif; ?>

    <!-- Jadual senarai aduan -->
    <div class="card shadow">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">📋 Senarai Aduan</h5>
        </div>
        <div class="card-body p-0">
            <table class="table table-striped table-hover mb-0">
                <thead class="table-dark">
                    <tr>
                        <th>#</th>
                        <?php if ($role == 'admin'): ?>
                            <th>Pengadu</th>
                        <?php endif; ?>
                        <th>Tajuk</th>
                        <th>Kategori</th>
                        <th>Status</th>
                        <th>Tarikh</th>
                        <?php if ($role == 'admin'): ?>
                            <th>Tindakan</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $bil = 1;
                    if ($result->num_rows > 0):
                        while ($row = $result->fetch_assoc()):
                    ?>
                    <tr>
                        <td><?= $bil++ ?></td>

                        <?php if ($role == 'admin'): ?>
                            <td><?= htmlspecialchars($row['username']) ?></td>
                        <?php endif; ?>

                        <td><?= htmlspecialchars($row['title']) ?></td>
                        <td><?= htmlspecialchars($row['category']) ?></td>

                        <!-- Badge warna ikut status -->
                        <td>
                            <?php
                            if ($row['status'] == 'Pending'):
                            ?>
                                <span class="badge bg-secondary">⏳ Pending</span>
                            <?php elseif ($row['status'] == 'In Progress'): ?>
                                <span class="badge bg-warning text-dark">🔄 In Progress</span>
                            <?php else: ?>
                                <span class="badge bg-success">✅ Resolved</span>
                            <?php endif; ?>
                        </td>

                        <td><?= date('d/m/Y', strtotime($row['created_at'])) ?></td>

                        <!-- Butang tindakan (hanya admin) -->
                        <?php if ($role == 'admin'): ?>
                        <td>
                            <a href="update_status.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-info">✏️ Kemaskini</a>
                            <a href="delete_complaint.php?id=<?= $row['id'] ?>"
                               class="btn btn-sm btn-danger"
                               onclick="return confirm('Adakah anda pasti mahu memadam aduan ini?')">🗑️ Padam</a>
                        </td>
                        <?php endif; ?>
                    </tr>
                    <?php
                        endwhile;
                    else:
                    ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted py-4">
                            📭 Tiada aduan dijumpai.
                            <?php if ($role == 'user'): ?>
                                <a href="add_complaint.php">Hantar aduan pertama anda!</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require 'footer.php'; ?>
