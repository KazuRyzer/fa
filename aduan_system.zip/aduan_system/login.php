<?php
session_start();
require 'config.php';

// Kalau dah log masuk, pergi dashboard terus
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

$error = "";

// Proses bila form dihantar
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Semak field tidak kosong
    if (empty($username) || empty($password)) {
        $error = "Sila masukkan username dan password!";
    } else {
        // Cari user dalam database
        $stmt = $conn->prepare("SELECT id, username, password, role FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $user = $result->fetch_assoc();

            // Semak password
            if (password_verify($password, $user['password'])) {
                // Password betul - simpan dalam session
                $_SESSION['user_id']  = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role']     = $user['role'];

                // Pergi ke dashboard
                header("Location: dashboard.php");
                exit();
            } else {
                $error = "Password tidak betul!";
            }
        } else {
            $error = "Username tidak dijumpai!";
        }
    }
}
?>

<?php require 'header.php'; ?>
<?php require 'navbar.php'; ?>

<div class="container main-content">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card shadow">
                <div class="card-header bg-primary text-white text-center">
                    <h4>🔑 Log Masuk</h4>
                </div>
                <div class="card-body">

                    <?php if (!empty($error)): ?>
                        <div class="alert alert-danger"><?= $error ?></div>
                    <?php endif; ?>

                    <form method="POST">
                        <div class="mb-3">
                            <label>Username</label>
                            <input type="text" name="username" class="form-control"
                                   placeholder="Masukkan username"
                                   value="<?= isset($_POST['username']) ? htmlspecialchars($_POST['username']) : '' ?>">
                        </div>
                        <div class="mb-3">
                            <label>Password</label>
                            <input type="password" name="password" class="form-control"
                                   placeholder="Masukkan password">
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Log Masuk</button>
                    </form>

                    <hr>
                    <p class="text-center">Belum ada akaun? <a href="register.php">Daftar di sini</a></p>

                    <!-- Info untuk testing -->
                    <div class="alert alert-info mt-2 small">
                        <strong>Admin:</strong> username: <code>admin</code> | password: <code>admin123</code>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require 'footer.php'; ?>
