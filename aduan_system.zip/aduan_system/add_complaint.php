<?php
session_start();
require 'config.php';

// ===== KAWALAN AKSES =====
// Hanya user biasa boleh hantar aduan (bukan admin)
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
if ($_SESSION['role'] == 'admin') {
    header("Location: dashboard.php");
    exit();
}

$error   = "";
$success = "";

// Proses bila form dihantar
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $title       = trim($_POST['title']);
    $category    = trim($_POST['category']);
    $description = trim($_POST['description']);
    $user_id     = $_SESSION['user_id'];

    // Validasi - semua field mesti diisi
    if (empty($title) || empty($category) || empty($description)) {
        $error = "Sila isi semua maklumat aduan!";
    } else {
        // Simpan aduan ke database
        $stmt = $conn->prepare("INSERT INTO complaints (user_id, title, category, description) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("isss", $user_id, $title, $category, $description);

        if ($stmt->execute()) {
            $success = "Aduan anda telah berjaya dihantar! Pihak kami akan menyemaknya.";
        } else {
            $error = "Ralat berlaku. Sila cuba lagi.";
        }
    }
}
?>

<?php require 'header.php'; ?>
<?php require 'navbar.php'; ?>

<div class="container main-content">
    <div class="row justify-content-center">
        <div class="col-md-7">
            <div class="card shadow">
                <div class="card-header bg-warning text-dark text-center">
                    <h4>➕ Hantar Aduan Baru</h4>
                </div>
                <div class="card-body">

                    <?php if (!empty($error)): ?>
                        <div class="alert alert-danger"><?= $error ?></div>
                    <?php endif; ?>

                    <?php if (!empty($success)): ?>
                        <div class="alert alert-success">
                            <?= $success ?>
                            <a href="dashboard.php">Lihat aduan saya</a>
                        </div>
                    <?php endif; ?>

                    <form method="POST">
                        <div class="mb-3">
                            <label>Tajuk Aduan <span class="text-danger">*</span></label>
                            <input type="text" name="title" class="form-control"
                                   placeholder="Contoh: Produk rosak selepas 2 hari"
                                   value="<?= isset($_POST['title']) ? htmlspecialchars($_POST['title']) : '' ?>">
                        </div>
                        <div class="mb-3">
                            <label>Kategori <span class="text-danger">*</span></label>
                            <select name="category" class="form-select">
                                <option value="">-- Pilih Kategori --</option>
                                <option value="Produk" <?= (isset($_POST['category']) && $_POST['category']=='Produk') ? 'selected' : '' ?>>Produk</option>
                                <option value="Perkhidmatan" <?= (isset($_POST['category']) && $_POST['category']=='Perkhidmatan') ? 'selected' : '' ?>>Perkhidmatan</option>
                                <option value="Penghantaran" <?= (isset($_POST['category']) && $_POST['category']=='Penghantaran') ? 'selected' : '' ?>>Penghantaran</option>
                                <option value="Bayaran" <?= (isset($_POST['category']) && $_POST['category']=='Bayaran') ? 'selected' : '' ?>>Bayaran</option>
                                <option value="Lain-lain" <?= (isset($_POST['category']) && $_POST['category']=='Lain-lain') ? 'selected' : '' ?>>Lain-lain</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label>Keterangan Aduan <span class="text-danger">*</span></label>
                            <textarea name="description" class="form-control" rows="5"
                                      placeholder="Terangkan masalah anda dengan terperinci..."><?= isset($_POST['description']) ? htmlspecialchars($_POST['description']) : '' ?></textarea>
                        </div>
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-warning">📤 Hantar Aduan</button>
                            <a href="dashboard.php" class="btn btn-secondary">Batal</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require 'footer.php'; ?>
