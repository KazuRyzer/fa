    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <footer class="bg-dark text-white text-center py-3 mt-4">
        <p class="mb-0">&copy; <?= date('Y') ?> Sistem Aduan Pelanggan. Hak Cipta Terpelihara.</p>
    </footer>

</body>
</html>
