<?php
session_start();
require 'config.php';

// ===== KAWALAN AKSES =====
// Hanya admin boleh kemaskini status
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Ambil ID aduan dari URL
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Semak ID sah
if ($id <= 0) {
    header("Location: dashboard.php");
    exit();
}

// Ambil maklumat aduan dari database
$stmt = $conn->prepare("SELECT complaints.*, users.username FROM complaints JOIN users ON complaints.user_id = users.id WHERE complaints.id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

// Kalau aduan tak jumpa
if ($result->num_rows == 0) {
    header("Location: dashboard.php");
    exit();
}

$complaint = $result->fetch_assoc();
$success = "";

// Proses kemaskini status
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $new_status = $_POST['status'];

    // Nilai yang dibenarkan
    $allowed = ['Pending', 'In Progress', 'Resolved'];

    if (in_array($new_status, $allowed)) {
        $update = $conn->prepare("UPDATE complaints SET status = ? WHERE id = ?");
        $update->bind_param("si", $new_status, $id);

        if ($update->execute()) {
            $success = "Status aduan telah berjaya dikemaskini!";
            $complaint['status'] = $new_status; // Kemas papar semasa
        }
    }
}
?>

<?php require 'header.php'; ?>
<?php require 'navbar.php'; ?>

<div class="container main-content">
    <div class="row justify-content-center">
        <div class="col-md-7">
            <div class="card shadow">
                <div class="card-header bg-info text-white">
                    <h4>✏️ Kemaskini Status Aduan</h4>
                </div>
                <div class="card-body">

                    <?php if (!empty($success)): ?>
                        <div class="alert alert-success">
                            <?= $success ?>
                            <a href="dashboard.php">Kembali ke Dashboard</a>
                        </div>
                    <?php endif; ?>

                    <!-- Maklumat aduan -->
                    <div class="mb-3 p-3 bg-light rounded">
                        <p><strong>Pengadu:</strong> <?= htmlspecialchars($complaint['username']) ?></p>
                        <p><strong>Tajuk:</strong> <?= htmlspecialchars($complaint['title']) ?></p>
                        <p><strong>Kategori:</strong> <?= htmlspecialchars($complaint['category']) ?></p>
                        <p><strong>Keterangan:</strong> <?= htmlspecialchars($complaint['description']) ?></p>
                        <p><strong>Tarikh:</strong> <?= date('d/m/Y H:i', strtotime($complaint['created_at'])) ?></p>
                    </div>

                    <!-- Form kemaskini -->
                    <form method="POST">
                        <div class="mb-3">
                            <label><strong>Status Semasa / Baru:</strong></label>
                            <select name="status" class="form-select">
                                <option value="Pending"     <?= $complaint['status']=='Pending'     ? 'selected' : '' ?>>⏳ Pending</option>
                                <option value="In Progress" <?= $complaint['status']=='In Progress' ? 'selected' : '' ?>>🔄 In Progress</option>
                                <option value="Resolved"    <?= $complaint['status']=='Resolved'    ? 'selected' : '' ?>>✅ Resolved</option>
                            </select>
                        </div>
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-info">💾 Simpan Perubahan</button>
                            <a href="dashboard.php" class="btn btn-secondary">Batal</a>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>

<?php require 'footer.php'; ?>
